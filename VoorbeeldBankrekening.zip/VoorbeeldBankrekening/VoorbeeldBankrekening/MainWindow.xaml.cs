﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VoorbeeldBankrekening
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        BankAccount ba = new BankAccount(200);        //new BankAccount(200);

        public MainWindow()
        {
            InitializeComponent();
            UpdateCurrentValue();

            //currentValueLabel.Content = ba.CurrentValue;
        }

        private void withdrawButton_Click(object sender, RoutedEventArgs e)
        {
            int withdraw = Convert.ToInt32(withdrawTextBox.Text);

            if (true)
            {
                ba.Withdraw(withdraw);
                UpdateCurrentValue();
            }
            else
            {
                //doe niets 

            }
            
            //currentValueLabel.Content = ba.CurrentValue;

            //string => iets anders PARSEN
            //int withdrawParse = int.Parse(withdrawTextBox.Text);
        }

        //Depositfunction

        public void UpdateCurrentValue()
        {
            currentValueLabel.Content = ba.CurrentValue;
        }
        
    }
}
