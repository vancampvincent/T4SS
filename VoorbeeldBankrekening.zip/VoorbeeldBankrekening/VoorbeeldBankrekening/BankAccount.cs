﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoorbeeldBankrekening
{
    class BankAccount
    {
        //oef 10.3 Bankrekening p267

        //prop tab tab
        public int CurrentValue
        {
            get ; set ;
        }
        //ctor //Constructor
        public BankAccount(int initieleValue)
        {
            this.CurrentValue = initieleValue;
        }


        public void Deposit(int aantal)
        {
            CurrentValue += aantal;

            //CurrentValue = CurrentValue + aantal;
        }

        public void Withdraw(int aantal)
        {
            CurrentValue -= aantal;
        }
    }
}
