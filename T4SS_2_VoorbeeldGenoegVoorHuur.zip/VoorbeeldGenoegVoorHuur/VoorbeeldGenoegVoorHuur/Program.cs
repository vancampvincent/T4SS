﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoorbeeldGenoegVoorHuur
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Om de volgende 'stap' te runnen:");
            Console.WriteLine("Rechter muisknop op het project / 'stap' dat je wilt runnen");
            Console.WriteLine("Selecteer: 'Set as StartUp Project''");
            Console.WriteLine();


            //Dit gaat veranderen
            Console.WriteLine("Hoeveel inkomsten heeft u?");
            int inkomsten = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Hoeveel huur moet u betalen?");
            int huur = Convert.ToInt32(Console.ReadLine());

            //Dit blijft hetzelfde => kan naar een methode
            if (inkomsten >= huur)
            {
                Console.WriteLine("U heeft genoeg!");
            }
            else
            {
                Console.WriteLine("Ajj dat wordt bijklussen");
            }
        }
    }
}
