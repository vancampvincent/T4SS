﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3MethodeZonderConsoleWrites
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hoeveel inkomsten heeft u?");
            int inkomstenInput = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Hoeveel huur moet u betalen?");
            int huurInput = Convert.ToInt32(Console.ReadLine());

            bool hebIkGenoeg = HebIkGenoegVoorHuur(inkomstenInput, huurInput);

            if (hebIkGenoeg)
            {
                Console.WriteLine("U heeft genoeg!");
            }
            else
            {
                Console.WriteLine("Ajj dat wordt bijklussen");
            }
        }
        static bool HebIkGenoegVoorHuur(int inkomsten, int huur)
        {
            if (inkomsten >= huur)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //een andere manier zou dit kunnen zijn.
        //dan lijkt het wat dom om dit in een methode te gieten.
        //denk eraan dat dit een oefening is met een korte probleemstelling.

        //static bool HebIkGenoegVoorHuur(int inkomsten, int huur)
        //{
        //    return inkomsten >= huur;
        //}
    }
}
