﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _4MethodeNaarWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ButtonAction_Click(object sender, RoutedEventArgs e)
        {
            //Console.WriteLine("Hoeveel inkomsten heeft u?");
            int inkomstenInput = Convert.ToInt32(textBoxInkomsten.Text);
                //Convert.ToInt32(Console.ReadLine());

            //Console.WriteLine("Hoeveel huur moet u betalen?");
            int huurInput = Convert.ToInt32(textBoxHuur.Text);
            //Convert.ToInt32(Console.ReadLine());

            bool hebIkGenoeg = HebIkGenoegVoorHuur(inkomstenInput, huurInput);

            if (hebIkGenoeg)
            {
                //Console.WriteLine("U heeft genoeg!");
                labelResult.Content = "U heeft genoeg!";
                //andere optie:
                //MessageBox.Show("U heeft genoeg!");
            }
            else
            {
                //Console.WriteLine("Ajj dat wordt bijklussen");
                labelResult.Content = "Ajj dat wordt bijklussen";
                //andere optie:
                //MessageBox.Show("Ajj dat wordt bijklussen");
            }
        }

        //Niets aan veranderd! Simpele copy-paste
        static bool HebIkGenoegVoorHuur(int inkomsten, int huur)
        {
            if (inkomsten >= huur)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
