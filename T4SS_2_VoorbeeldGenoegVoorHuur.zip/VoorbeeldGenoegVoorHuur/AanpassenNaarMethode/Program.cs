﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AanpassenNaarMethode
{
    class Program
    {
        static void Main(string[] args)
        {
            //ik heb de inkomsten naar inkomstenInput en huur naar huurInput veranderd om te laten zien dat je 
            //andere namen kan gebruiken voor parameters bij het AANROEPEN van een methode als bij het vastleggen van een methode
            Console.WriteLine("Hoeveel inkomsten heeft u?");
            int inkomstenInput = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Hoeveel huur moet u betalen?");
            int huurInput = Convert.ToInt32(Console.ReadLine());

            HebIkGenoegVoorHuur(inkomstenInput, huurInput);
        }
        static void HebIkGenoegVoorHuur(int inkomsten, int huur)
        {
            if (inkomsten >= huur)
            {
                Console.WriteLine("U heeft genoeg!");
            }
            else
            {
                Console.WriteLine("Ajj dat wordt bijklussen");
            }
        }
    }
}
