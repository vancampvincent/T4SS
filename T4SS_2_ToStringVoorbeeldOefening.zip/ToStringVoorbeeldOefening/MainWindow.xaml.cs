﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ToStringVoorbeeldOefening
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            string result = "26 Hallo";
            Person person = new Person("Vincent", "Van Camp");
            Employee employee = new Employee("John", "Doe", 123); 

            //MessageBox.Show("???");
            //MessageBox.Show(Convert.ToString(5));
            //MessageBox.Show("Hallo");
            //MessageBox.Show(result);
            //MessageBox.Show(person.ToString());
            
            listBox.Items.Add("Hallo");
            listBox.Items.Add(1);
            listBox.Items.Add(person);
            listBox.Items.Add(employee);
        }
    }
}
