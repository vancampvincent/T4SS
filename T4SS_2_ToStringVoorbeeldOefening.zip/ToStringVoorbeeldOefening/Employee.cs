﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToStringVoorbeeldOefening
{
    public class Employee : Person
    {
        public int EmployeeNumber { get; set; }

        public Employee(string firstName, string lastName, int employeeNumber) 
            : base(firstName, lastName)
        {
            EmployeeNumber = employeeNumber;
        }

        //Object
        // V
        // Person
        // V
        // Employee
        public override string ToString()
        {
            //return FirstName + " " + LastName + " Number = " + EmployeeNumber;
            return base.ToString() + " Number = " + EmployeeNumber;
        }

        
    }
}
