﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VoorbeeldLists
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<string> stringetjes; 
        public MainWindow()
        {
            InitializeComponent();

            stringetjes = new List<string>();
            stringetjes.Add("Hallo!");
            stringetjes.Add("Alles goed?");

            //for ==> array
            //foreach ==> lists

            //WERKING ARRAYS
            //int[] arrayke = new int[5];
            ////0 - 4
            //int resultaat = arrayke[0]; //tussen [] is index
            //for (int i = 0; i < arrayke.Length; i++)
            //{
            //    int result = arrayke[i];
            //}
            ToonLijst();

            //tekstVenster.Text = stringetjes.ToString();
        }

        private void toevoegKnop_Click(object sender, RoutedEventArgs e)
        {
            string nieuweInput = inputTextBox.Text; //niets instaat = ""

            //if(String.IsNullOrEmpty(nieuweInput))
            if (nieuweInput == "")
            {
                //doe niets want de waarde is leeg
            }
            else
            {
                stringetjes.Add(nieuweInput);
                ToonLijst();
            }
            
        }

        private void clearTextVak_Click(object sender, RoutedEventArgs e)
        {                        
            stringetjes.Clear();
            ToonLijst();


        }
        public void ToonLijst()
        {
            tekstVenster.Text = "<Lijstje>\n";
            foreach (string item in stringetjes)
            {
                tekstVenster.Text += item + "\n";
            }
        }

        private void sorteerKnop_Click(object sender, RoutedEventArgs e)
        {
            stringetjes.Sort();
            ToonLijst();
        }

        private void zoekKnop_Click(object sender, RoutedEventArgs e)
        {
            //de echte zoekcheck
            string zoekString = inputTextBox.Text;
            bool bestaat = false;
            foreach (string item in stringetjes)
            {
                if (zoekString == item)
                {
                    bestaat = true;
                }
            }
            

            //de afhandeling van het al dan niet vinden
            if (bestaat)
                //= (bestaat == true)
            {
                MessageBox.Show(zoekString + " bestaat al!");
            }
            else
            {
                MessageBox.Show(zoekString + " bestaat niet");
            }
        }
    }
}
