﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoorbeeldProperties
{
    class Program
    {
        static void Main(string[] args)
        {
            //int getal = 5;
            //string test = "test";
            //bool isHetZo = true;

            Person persoon1 = new Person();
            persoon1.FirstName = "Vincent";
            string result = persoon1.FirstName;
            //cw + tab + tab
            Console.WriteLine(result);

            persoon1.LastName = "Van Camp";
            string result2 = persoon1.LastName;
            Console.WriteLine(result2);

            Console.WriteLine(persoon1.FullName);

            //DateTime date = new DateTime();
            //date.
        }
    }
}
