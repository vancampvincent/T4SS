﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoorbeeldProperties
{
    public class Person
    {
        //variabelen
        //private string firstName;
        private string firstName;
        private string lastName;

        //properties
        public string FirstName
        {
            get
            {
                return firstName.ToUpper();
            }
            set
            {
                string newValue = value;
                if (newValue == "Vincent")
                {
                    firstName = "Sam";
                }
                else
                {
                    firstName = newValue;
                }
            }
        }
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }
        public string FullName
        {
            get
            {
                return FirstName + " " + lastName;
            }
        }




        //automatische Property => prop + tab+tab
        public int Age { get; set; }


        //methoden
        //public string GetLastName()
        //{
        //    return lastName;
        //}
        //public void SetLastName(string newLastName)
        //{
        //    lastName = newLastName;
        //}
    }
}
