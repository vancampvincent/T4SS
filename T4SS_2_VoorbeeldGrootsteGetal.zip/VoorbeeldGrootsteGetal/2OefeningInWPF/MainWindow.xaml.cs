﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _2OefeningInWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Console.WriteLine("Geef een getal (1/3)");
            int getal1 = Convert.ToInt32(textBox1.Text);
                //Console.ReadLine());

            //Console.WriteLine("Geef een getal (2/3)");
            int getal2 = Convert.ToInt32(textBox2.Text);
                //Console.ReadLine());

            //Console.WriteLine("Geef een getal (3/3)");        
            int getal3 = Convert.ToInt32(textBox3.Text);
                //Console.ReadLine());

            int grootsteGetal = GeefHetGrootsteGetal(getal1, getal2, getal3);

            labelResult.Content = "Grootste getal: "+ grootsteGetal;
            //MessageBox.Show("Grootste getal: " + grootsteGetal);
            //Console.WriteLine("Grootste getal: " + grootsteGetal);
        }

        static int GeefHetGrootsteGetal(int getal1, int getal2, int getal3)
        {
            //>= om op te vangen als sommige getallen gelijk zijn aan elkaar, kan eleganter en beter opgevangen worden
            //maar is niet het belangrijkste van de oefening.

            if (getal1 >= getal2 && getal1 >= getal3)
            {
                return getal1;
            }
            else if (getal2 >= getal1 && getal2 >= getal3)
            {
                return getal2;
            }
            else
            {
                return getal3;
            }

        }
    }
}
