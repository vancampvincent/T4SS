﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoorbeeldGrootsteGetal
{
    class Program
    {
        static void Main(string[] args)
        {
            // Vraag aan de gebruiker 3 cijfers. Geef het grootste cijfer terug.


            Console.WriteLine("Geef een getal (1/3)");
            int getal1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Geef een getal (2/3)");
            int getal2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Geef een getal (3/3)");
            int getal3 = Convert.ToInt32(Console.ReadLine());

            int grootsteGetal = GeefHetGrootsteGetal(getal1, getal2, getal3);

            Console.WriteLine("Grootste getal: "+grootsteGetal);

            /*Je merkt dat deze code niet echt uitbreidbaar is
             * Stel: ik wil ipv 3 cijfers 5 of 6 of meer cijfers opvragen.
             * Dan moet ik momenteel heel veel copy paste werk doen en elke keer mijn methode parameters aanpassen.
             * 
             * Als EXTRA uitdagende oefening: lees hoofdstuk 8 en 13 door
             * 8: for lussen
             * 13: lists
             * om de oplossing te verbeteren met lists en for lussen.
             * We gaan dit volgende keer (als we tijd hebben) samen behanden
             */
        }

        static int GeefHetGrootsteGetal(int getal1, int getal2, int getal3)
        {
            //>= om op te vangen als sommige getallen gelijk zijn aan elkaar, kan eleganter en beter opgevangen worden
            //maar is niet het belangrijkste van de oefening.

            if (getal1>= getal2 && getal1 >= getal3)
            {
                return getal1;
            }
            else if (getal2 >= getal1 && getal2 >= getal3)
            {
                return getal2;
            }
            else
            {
                return getal3;
            }

        }
    }
}
