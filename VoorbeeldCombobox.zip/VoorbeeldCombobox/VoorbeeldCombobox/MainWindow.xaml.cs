﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VoorbeeldCombobox
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Persoon> personen;
        List<string> stringetjes;

        public MainWindow()
        {
            InitializeComponent();

            personen = new List<Persoon>()
            {
                new Persoon("Vincent","Van Camp",29),
                new Persoon("John","Doe",100)
            };

            stringetjes = new List<string>
            {
                "Hallo",
                "Alles goed?",
                "Met mij wel"
            };

            foreach (string item in stringetjes)
            {
                ComboboxStrings.Items.Add(item);
            }

            foreach (Persoon persoon in personen)
            {
                ComboboxPersoon.Items.Add(persoon);
            }

            foreach (Departement departement in Enum.GetValues(typeof(Departement)))
            {
                ComboboxEnum.Items.Add(departement);
            }

            //
            // ComboboxEnum.Items.Add(Departement.HR);
            // ComboboxEnum.Items.Add(Departement.IT);
            // ComboboxEnum.Items.Add(Departement.Productie);

            //dit is hetzelfde als:
            //personen = new List<Persoon>();
            //personen.Add(new Persoon("Vincent", "Van Camp", 29));

        }

        private void ComboboxEnum_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }

        private void ComboboxPersoon_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //(Persoon) => Casting
            Persoon selectedPersoon = (Persoon)ComboboxPersoon.SelectedItem;

            OutputTextBlock.Text = selectedPersoon.AlleInfo();
        }

        private void ComboboxStrings_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string selectedStringValue = (string)ComboboxStrings.SelectedValue;

            OutputTextBlock.Text = selectedStringValue;
        }
    }
}
