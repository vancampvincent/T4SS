﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoorbeeldCombobox
{
    enum Departement
    {
        HR,
        IT,
        Productie
    }
    class Persoon
    {
        public string Voornaam { get; set; }
        public string Achternaam { get; set; }
        public int Leeftijd { get; set; }

        public Persoon(string voornaam, string achternaam, int leeftijd)
        {
            Voornaam = voornaam;
            Achternaam = achternaam;
            Leeftijd = leeftijd;
        }

        public string AlleInfo()
        {
            string output =
                Voornaam + "\n"
                + Achternaam + "\n"
                + Leeftijd + "\n";
            return output;
        }

        public override string ToString()
        {
            return Voornaam;
        }
    }
}
