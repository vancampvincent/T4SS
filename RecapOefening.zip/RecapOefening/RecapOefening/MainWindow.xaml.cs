﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RecapOefening
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Normaal> lijstjeVoorObjecten;

        public MainWindow()
        {
            InitializeComponent();

            lijstjeVoorObjecten = new List<Normaal>();

            NormaalRadioButton.IsChecked = true;
        }

        private void ToevoegenButton_Click(object sender, RoutedEventArgs e)
        {
            Normaal nieuwItem;

            try
            {
                string naam = NaamTextBox.Text;
                int aantal = Convert.ToInt32(AantalTextBox.Text);

                if (NormaalRadioButton.IsChecked.Value)
                {
                    nieuwItem = new Normaal(naam, aantal);
                }
                else
                {
                    string extraInfo = ExtraInfoTextBox.Text;

                    nieuwItem = new Speciaal(naam, aantal, extraInfo);
                }
                
                lijstjeVoorObjecten.Add(nieuwItem);
                LijstVanItemsListBox.Items.Add(nieuwItem);
                
            }
            catch (FormatException)
            {
                MessageBox.Show("Oeps... je hebt waarschijnlijk tekst in een int willen steken");
            }
            catch (OverflowException)
            {
                MessageBox.Show("Aantal is te groot");
            }
            //GENERIEK
            catch (Exception)
            {
                MessageBox.Show("Something went wrong");
            }
            

        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            if (NormaalRadioButton.IsChecked.Value)
            {
                ExtraInfoTextBox.Visibility = Visibility.Hidden;
                ExtraInfoLabel.Visibility = Visibility.Hidden;
            }
            else
            {
                ExtraInfoTextBox.Visibility = Visibility.Visible;
                ExtraInfoLabel.Visibility = Visibility.Visible;
            }
        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void LijstVanItemsListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            GegevensListBox.Items.Clear();
            Normaal geselecteerdItem = (Normaal)LijstVanItemsListBox.SelectedItem;
            
            //GegevensListBox.Items.Add(geselecteerdItem.Aantal);
            //GegevensListBox.Items.Add(geselecteerdItem.Naam);
            //GegevensListBox.Items.Add(geselecteerdItem.ext);
            GegevensListBox.Items.Add(geselecteerdItem.GeefInfo());
        }

        //DUBBELE CODE
        //private void SpeciaalRadioButton_Checked(object sender, RoutedEventArgs e)
        //{
        //    if (NormaalRadioButton.IsChecked.Value)
        //    {
        //        ExtraInfoTextBox.Visibility = Visibility.Hidden;
        //        ExtraInfoLabel.Visibility = Visibility.Hidden;
        //    }
        //    else
        //    {
        //        ExtraInfoTextBox.Visibility = Visibility.Visible;
        //        ExtraInfoLabel.Visibility = Visibility.Visible;
        //    }
        //}

        //private void DoeIets()
        //{
        //    lijstjeVoorObjecten
        //}
    }
}
