﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecapOefening
{
    class Normaal
    {
        public string Naam { get; set; }
        public int Aantal { get; set; }

        public Normaal(string naam, int aantal)
        {
            Naam = naam;
            Aantal = aantal;
        }

        public override string ToString()
        {
            //base: object = namespace + . + naam klasse 
            //return base.ToString();
            return Naam + " - " + Aantal;
        }

        public virtual string GeefInfo()
        {
            return
                "Naam: " + Naam + "\n" +
                "Aantal:" + Aantal;
            //return "";
        }

    }
}
