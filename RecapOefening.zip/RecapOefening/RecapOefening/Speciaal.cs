﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecapOefening
{
    class Speciaal : Normaal
    {
        public string ExtraInfo { get; set; }

        public Speciaal(string naam, int aantal, string extraInfo) : base(naam, aantal)
        {
            ExtraInfo = extraInfo;
        }

        public override string ToString()
        {
            // base : Normaal = Naam + " - " + Aantal;
            //return base.ToString();
            // Naam + " - " + Aantal + "(S)"
            //return Naam + " - " + Aantal + "(S)";
            return base.ToString() + "(S)";
        }

        public override string GeefInfo()
        {
            return
                base.GeefInfo() + "\n"
                + "ExtraInfo: " + ExtraInfo;
            //return "ExtraInfo: " + ExtraInfo;
        }
    }
}
