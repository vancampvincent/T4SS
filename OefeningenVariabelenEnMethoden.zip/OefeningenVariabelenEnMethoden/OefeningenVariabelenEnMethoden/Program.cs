﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OefeningenVariabelenEnMethoden
{
    class Program
    {
        static void Main(string[] args)
        {
            int minderjarigeLeeftijd = 6;
            //string naam = "Vincent";
            //int vakantieDagen = 14;
            int meerderjarigeLeeftijd = 19;

            IsMeerderjarigOfMinderjarig(minderjarigeLeeftijd);
            IsMeerderjarigOfMinderjarig(meerderjarigeLeeftijd);


        }

        static void IsMeerderjarigOfMinderjarig(int leeftijd)
        {
            //start verandering
            int meerderjarigeLeeftijd = 18;
            //booleans: > < == != >= <=

            if (leeftijd > meerderjarigeLeeftijd)
            {
                Console.WriteLine("Meerderjarig");
            }
            else
            {
                Console.WriteLine("Minderjarig");
            }
            //einde verandering
        }
    }
}
