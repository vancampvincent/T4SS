﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VoorbeeldInWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            //Console.WriteLine("Geef uw leeftijd");
            int inputLeeftijd = Convert.ToInt32(textBox.Text);

            //string naam = "Vincent";
            //int vakantieDagen = 14;
            //int meerderjarigeLeeftijd = 19;

            bool isMeerderjarig;
            isMeerderjarig = IsMeerderjarig(inputLeeftijd);

            if (isMeerderjarig)
            {
                //Console.WriteLine("Meerderjarig");
                resultLabel.Content = "Meerderjarig";
            }
            else
            {
                //Console.WriteLine("Minderjarig");
                resultLabel.Content = "Minderjarig";
            }
        }

        static bool IsMeerderjarig(int leeftijd)
        {
            //start verandering
            int meerderjarigeLeeftijd = 18;
            //booleans: > < == != >= <=

            if (leeftijd > meerderjarigeLeeftijd)
            {
                return true;
            }
            else
            {
                return false;
            }
            //einde verandering
        }
    }
}
