﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TweedeProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Geef uw leeftijd");            
            int inputLeeftijd = Convert.ToInt32(Console.ReadLine());

            //string naam = "Vincent";
            //int vakantieDagen = 14;
            //int meerderjarigeLeeftijd = 19;

            bool isMeerderjarig;
            isMeerderjarig = IsMeerderjarig(inputLeeftijd);

            if (isMeerderjarig)
            {
                Console.WriteLine("Meerderjarig");
                //resultLabel.Text = "Meerderjarig";
            }
            else
            {
                Console.WriteLine("Minderjarig");
                //resultLabel.Text = "Minderjarig";
            }
        }

        static bool IsMeerderjarig(int leeftijd)
        {
            //start verandering
            int meerderjarigeLeeftijd = 18;
            //booleans: > < == != >= <=

            if (leeftijd > meerderjarigeLeeftijd)
            {
                return true;
            }
            else
            {
                return false;
            }
            //einde verandering
        }
    }
}
