﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VoorbeeldBankrekeningen
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            TestMyCode();


        }

        public void TestMyCode()
        {
            Bankaccount bankaccount = new Bankaccount(10, "Vincent");
            bankaccount.Owner = "Sam";
            //bankaccount.Saldo = 10000;

            //TestDebitAccount();
            TestSavingsAccount();


        }
        public void TestDebitAccount()
        {
            double result;
            Debitaccount debitaccount = new Debitaccount(0, "Sam");            
            result = debitaccount.Withdraw(125); //zou goed moeten gaan => result = 125
            MessageBox.Show(result.ToString());
            result = debitaccount.Withdraw(125); //zou niet mogen doorgaan => result = 0
            MessageBox.Show(result.ToString());
        }
        public void TestSavingsAccount()
        {
            double result;
            Savingsaccount savingsaccount = new Savingsaccount(0, "Vincent", true);
            result = savingsaccount.Deposit(50);
            MessageBox.Show(result.ToString()); //zou niet mogen doorgaan => result = 0;
            result = savingsaccount.Deposit(100); //zou goed moeten gaan => result = 100
            MessageBox.Show(result.ToString());

            result = savingsaccount.CalculateInterest(); //zou goed moeten gaan => result = 5;
            MessageBox.Show(result.ToString());
        }
    }
}
