﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoorbeeldBankrekeningen
{
    class Bankaccount
    {
        //variabelen


        //properties
        //automatische property = prop tab tab => geen verandering in default gedrag
        public double Saldo { get; private set; }
        public string Owner { get; set; }

        //methodes
        public Bankaccount(double saldo, string owner)
        {
            Saldo = saldo;
            Owner = owner;
        }


        public virtual double Withdraw(double amount)
        {
            //Saldo = Saldo - amount;
            Saldo -= amount;
            // EXTRA LOGICA
            return amount;
        }

        public virtual double Deposit(double amount)
        {
            Saldo += amount;
            return amount;
        }

        public virtual double CalculateInterest()
        {
            if (Saldo >= 100)
            {
                // Saldo + interest
                //return Saldo * 1.01;

                // pure interest
                return Saldo * 0.01;
            }
            else
            {
                return 0;
            }
        }
    }
}
