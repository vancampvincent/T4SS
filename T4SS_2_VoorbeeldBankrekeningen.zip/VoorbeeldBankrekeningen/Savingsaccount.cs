﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoorbeeldBankrekeningen
{
    class Savingsaccount : Bankaccount
    {
        public bool IsPremium { get; set; }

        public Savingsaccount(double saldo, string owner, bool isPremium) : base(saldo, owner)
        {
            IsPremium = isPremium;
        }

        public override double Deposit(double amount)
        {
            if (amount >= 100)
            {
                return base.Deposit(amount);
            }
            else
            {
                return base.Deposit(0);
            }
            
        }

        public override double CalculateInterest()
        {
            return Saldo * 0.05;
        }
    }
}
