﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoorbeeldBankrekeningen
{
    class Debitaccount : Bankaccount
    {
        public Debitaccount(double saldo, string owner) : base(saldo, owner)
        {
        }

        public override double Withdraw(double amount)
        {
            /*
             * Saldo = -105
             * amount = 50
             * Saldo = -155 X
             * Saldo - amount (-155) >= -125
             * 
             */

            if (Saldo - amount >= -125)
            {
                return base.Withdraw(amount);
            }
            else
            {
                return base.Withdraw(0);
            }
            
        }
    }
}
