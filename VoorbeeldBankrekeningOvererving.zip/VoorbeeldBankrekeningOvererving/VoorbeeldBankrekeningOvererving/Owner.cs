﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoorbeeldBankrekeningOvererving
{
    public class Owner
    {
        //variabelen

        //properties
        public string Voornaam { get; set; }
        public string Achternaam { get; set; }
        public int Leeftijd { get; set; }
        //...

        //Methoden
        public Owner(string voornaam, string achternaam, int leeftijd)
        {
            Voornaam = voornaam;
            Achternaam = achternaam;
            Leeftijd = leeftijd;
        }

        public override string ToString()
        {
            // Voornaam
            // Achternaam
            // Leeftijd
            string resultaat = "";

            resultaat += Voornaam + "\n"; // \n = ga naar nieuwe lijn
            resultaat += Achternaam + "\n";
            resultaat += Leeftijd;
            //zonder \n
            //VincentVanCamp29

            //met \n
            //Vincent
            //VanCamp
            //29
            return resultaat;


            //VoorbeeldBankrekeningOvererving.Owner
            //return base.ToString();
        }
    }
}
