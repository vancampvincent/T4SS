﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoorbeeldBankrekeningOvererving
{
    public abstract class Bankaccount
    {
        private double saldo;

        public double Saldo
        {
            get { return saldo; }
            set { saldo = value; }
        }
        private Owner eigenaar;

        public Owner Eigenaar
        {
            get { return eigenaar; }
            set { eigenaar = value; }
        }


        public Bankaccount(int saldo, Owner owner)
        {
            this.Saldo = saldo;
            this.Eigenaar = owner;
        }

        public virtual void Deposit(int amount)
        {
            Saldo += amount;
            //Saldo = Saldo + amount;
        }

        public virtual void Withdraw(int amount)
        {
            Saldo -= amount;
            //Saldo = Saldo - amount;
        }
    }
}
