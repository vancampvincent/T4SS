﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VoorbeeldBankrekeningOvererving
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Debitaccount debit = new Debitaccount(5);
        Owner eigenaarSavings;
        Savingsaccount savings;

        public MainWindow()
        {
            InitializeComponent();

            eigenaarSavings = new Owner("Vincent", "Van Camp", 29);
            savings = new Savingsaccount(5, eigenaarSavings);

            //Bankaccount ba = new Bankaccount(5);
            saldoLabel.Content = "Saldo: " +savings.Saldo;
        }

        private void withdrawButton_Click(object sender, RoutedEventArgs e)
        {
            int amount = Convert.ToInt32(amountTextBox.Text);
            savings.Withdraw(amount);
            saldoLabel.Content = "Saldo: " + savings.Saldo;
        }

        private void depositButton_Click(object sender, RoutedEventArgs e)
        {
            int amount = Convert.ToInt32(depositAmount.Text);
            savings.Deposit(amount);
            saldoLabel.Content = "Saldo: " + savings.Saldo;
        }

        private void berekenInterestButton_Click(object sender, RoutedEventArgs e)
        {
            double result = savings.BerekenInterest();
            MessageBox.Show(result.ToString());
            savings.Saldo += result;
            saldoLabel.Content = "Saldo: " + savings.Saldo;
        }

        private void eigenaarKnop_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(eigenaarSavings.ToString());
        }
    }
}
