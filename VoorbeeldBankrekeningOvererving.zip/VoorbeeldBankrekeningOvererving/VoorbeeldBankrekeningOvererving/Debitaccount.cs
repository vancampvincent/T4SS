﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoorbeeldBankrekeningOvererving
{
    public class Debitaccount : Bankaccount
    {
        public Debitaccount(int saldo, Owner owner) : base(saldo, owner)
        {
        }

        public override void Withdraw(int amount)
        {
            if (Saldo - amount < -125)
            {
                //DoNothing
                //geef string terug om dan gebruikt te worden in messagebox
            }
            else
            {
                base.Withdraw(amount);
            }
            
        }
    }
}
