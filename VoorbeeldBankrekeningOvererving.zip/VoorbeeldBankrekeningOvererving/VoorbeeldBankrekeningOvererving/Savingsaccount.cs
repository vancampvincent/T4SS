﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoorbeeldBankrekeningOvererving
{
    public class Savingsaccount : Bankaccount
    {
        public Savingsaccount(int saldo, Owner owner) : base(saldo, owner)
        {
        }

        public override void Deposit(int amount)
        {
            if (amount >= 100)
            {
                base.Deposit(amount);
            }
            else
            {
                //Doe niets of doe iets 
            }
        }

        public double BerekenInterest()
        {
            double percentage = 0.02; // = 2%

            return Saldo * percentage;
        }
    }
}
